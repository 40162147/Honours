import org.neuroph.core.NeuralNetwork;

public class NeuralNetPlayer extends Player 
{
	String File;
	NeuralNetwork neuralnet = null;
	
	public void create(String id, String location)
	{
		Name = id;
		File = location;
		
		neuralnet = NeuralNetwork.createFromFile(File);
	}
	
	
	int Play(int Points, int DealerLow, int DealerHigh)
	{
		Score = Points;
		highestScoreDealer = DealerHigh;
		lowestScoreDealer = DealerLow;
		
		
		neuralnet.setInput(Score, lowestScoreDealer, highestScoreDealer);
		  
		neuralnet.calculate();
	  
		double[] result = neuralnet.getOutput();
		
		if (result[0] >= 0.5)
		{
			Hit = 1;
		}
		else
		{
			Hit = 0;
		}
			
		
		return Hit;
	}
}
