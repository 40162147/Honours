import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;
import java.util.List;
import java.util.Map;




public class DecisionTree
{

	private Node root;
	
	private int maxDepth = 15;
	
	private Randomness impurityCalculationMethod = new Gini();
	
	private double homogenityPercentage = 0.9;
	
	public Node getRoot()
	{
		return root;
	}
	
	public void train(List<DataSample> trainingData, List<FeatureInterface> features)
	{
		root = growTree(trainingData, features, 1);
	}
	
	protected Node growTree(List<DataSample> trainingData, List<FeatureInterface> features, int currentDepth)
	{
		Label currentNodeLabel = null;
	        // if data set already homogeneous enough (has label assigned) make this node a leaf
	    if ((currentNodeLabel = getLabel(trainingData)) != null) 
	     { 
	    	return Node.newLeafNode(currentNodeLabel);
	     }
	  
		boolean stoppingCriteriaReached = features.isEmpty() || currentDepth >= maxDepth;
		if (stoppingCriteriaReached) 
	    {
			Label majorityLabel = getMajorityLabel(trainingData);
	    	 
			return Node.newLeafNode(majorityLabel);	            	      
	    }

	    FeatureInterface bestSplit = findBestSplitFeature(trainingData, features); // get best set of literals
	     
	    List<List<DataSample>> splitData = bestSplit.split(trainingData);
	       

	        // remove best split from features 
	 
	    List<FeatureInterface> newFeatures = features.stream().filter(p -> !p.equals(bestSplit)).collect(toList());
	    Node node = Node.newNode(bestSplit);
	    for (List<DataSample> subsetTrainingData : splitData) 
	    { // add children to current node according to split
	    	if (subsetTrainingData.isEmpty())
	    	{
	                // if subset data is empty add a leaf with label calculated from initial data
	    		node.addChild(Node.newLeafNode(getMajorityLabel(trainingData)));	            
	    	} 
	    	else 
	    	{
	             // grow tree further recursively
	    		node.addChild(growTree(subsetTrainingData, newFeatures, currentDepth + 1));	            
	    	}
	        
	    }

	    return node;
	     
	}
	
	public Label classify(DataSample dataSample) 
	{
        Node node = root;
        while (!node.isLeaf()) 
        { 
        	// go through tree until leaf is reached
            // only binary splits for now - has feature first child node(left branch), does not have feature second child node(right branch).
            if (dataSample.has(node.getFeature())) 
            {
                node = node.getChildren().get(0); 
            } 
            else 
            {
                node = node.getChildren().get(1);
            }
        }
        return node.getLabel();
    }
	
	 protected FeatureInterface findBestSplitFeature(List<DataSample> data, List<FeatureInterface> features) 
	 {
	        double currentImpurity = 1;
	        FeatureInterface bestSplitFeature = null; 

	        for (FeatureInterface feature : features)
	        {
	            List<List<DataSample>> splitData = feature.split(data);
	            // totalSplitImpurity = sum(singleLeafImpurities) / nbOfLeafs
	            // in other words splitImpurity is average of leaf impurities
	            double calculatedSplitImpurity = splitData.parallelStream().filter(list -> !list.isEmpty()).mapToDouble(list -> impurityCalculationMethod.calculateImpurity(list)).average().getAsDouble();
	            if (calculatedSplitImpurity < currentImpurity) 
	            {
	                currentImpurity = calculatedSplitImpurity;
	                bestSplitFeature = feature;
	            }
	        }

	        return bestSplitFeature;
	    }
	 
	 
	 protected Label getLabel(List<DataSample> data) 
	 {
	        // group by to map <Label, count>
	        Map<Label, Long> labelCount = data.parallelStream().collect(groupingBy(DataSample::getLabel, counting()));
	        long totalCount = data.size();
	        for (Label label : labelCount.keySet()) 
	        {
	        	long nbOfLabels = labelCount.get(label);
	        	if (((double) nbOfLabels / (double) totalCount) >= homogenityPercentage) 
	        	{
	        		return label;
	            }
	        }
	        return null;
	 }

	 
	 protected Label getMajorityLabel(List<DataSample> data) 
	 {
	        // group by to map <Label, count> like in getLabels() but return Label with most counts
	        return data.parallelStream().collect(groupingBy(DataSample::getLabel, counting())).entrySet().stream().max(Map.Entry.comparingByValue()).get().getKey();
	   
	 }
	 
	
	 
	 
	 
	 
	 
	
	
}
