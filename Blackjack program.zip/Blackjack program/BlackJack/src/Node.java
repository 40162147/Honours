import java.util.ArrayList;
import java.util.List;

public class Node 
{
    private static final String LEAF_NODE_NAME = "Leaf";

    /** Node's feature used to split it further. */
    private FeatureInterface feature;
    
    private Label label;
    
    private List<Node> children = new ArrayList<Node>();
    
    private Node(FeatureInterface feature) 
    {
        this.feature = feature;
    }

    private Node(FeatureInterface feature, Label label) 
    {
        this.label = label;
        this.feature = feature;
    }

    public static Node newNode(FeatureInterface feature) 
    {
        return new Node(feature);
    }

    public static Node newLeafNode(Label label) 
    {
        return new Node(null, label);
    }
    
    public void addChild(Node child) 
    {
        children.add(child);
    }
    
    public List<Node> getChildren() 
    {
        return children;
    }
    
    public Label getLabel() 
    {
        return label;
    }

    public boolean isLeaf() 
    {
        return label != null;
    }

    public FeatureInterface getFeature()
    {
        return feature;
    }

    public String getName()
    {
        return feature != null ? feature.toString() : LEAF_NODE_NAME;
    }
}
