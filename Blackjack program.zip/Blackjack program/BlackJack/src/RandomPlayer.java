import java.util.Random;


public class RandomPlayer extends Player 
{
	
	int Play(int Points, int DealerLow, int DealerHigh)
	{
		
		Random rand = new Random(); 
		Hit = rand.nextInt(2); 
		
		
		return Hit;
	}
	

}
