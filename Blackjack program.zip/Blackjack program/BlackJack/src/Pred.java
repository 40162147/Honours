import java.util.function.Predicate;

public class Pred 
{
	
	public static <T> Predicate<T> isEqual(T value) 
	{
		
		return p -> p.equals(value);
		
	}

	public static Predicate<Integer> moreThanD(int value) 
	{
	       
		return p -> p > value;
	   
	}

	    
	public static Predicate<Integer> lessThanD(int value) 
	{
		       
		return p -> p < value;
	    
	}

	   
	public static Predicate<Integer> moreThan(int value) 
	{
	        
		return p -> p > value;
	    
	}

	    
	public static Predicate<Integer> lessThan(int value) 
	{
	       
		return p -> p < value;
	   
	}

	   
	public static Predicate<Integer> between(int from, int to) 
	{
	        
		return moreThan(from).and(lessThan(to));
	    
	}

	   
	public static Predicate<Integer> betweenD(int from, int to) 
	{
	        
		return moreThanD(from).and(lessThanD(to));
	    
	}

	   
	public static Predicate<String> startsWith(String prefix) 
	{
	        
		return p -> p != null && p.startsWith(prefix);
	    
	}

}
