import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseBool;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvListReader;
import org.supercsv.io.ICsvListReader;
import org.supercsv.prefs.CsvPreference;
import org.supercsv.util.CsvContext;

public class DecisionTreePlayer extends Player 
{
	
	int Type;
	List<DataSample> trainingData = new ArrayList<>();
	DecisionTree Tree = new DecisionTree();
	List<FeatureInterface> features = new ArrayList<>();
	
	void Train() throws IOException
	{
		 trainingData = readData(true, Type);
		 features = getFeatures(); 
	     Tree.train(trainingData, features);      
	}
	
	public void create(String id, int type)
	{
		Name = id;
		Type = type;
	}
	
	int Play(int Points, int DealerLow, int DealerHigh)
	{
		
		Score = Points;
		highestScoreDealer = DealerHigh;
		lowestScoreDealer = DealerLow;
		
		try 
		{
			Train();
		} 
		catch (IOException e1) 
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		PrintWriter pw = null;
        try 
    	{
        	pw = new PrintWriter(new File("/Users/assas/Desktop/test.csv"));
     	} 
        catch (FileNotFoundException e) 
        {
		
        	e.printStackTrace();
     	}
     	StringBuilder sb = new StringBuilder();
		  
     	sb.append("CurrentScore");
     	sb.append(",");
     	sb.append("LowestScoreDealer");
     	sb.append(",");
     	sb.append("HighestScoreDealer");
     	sb.append('\n');
     	sb.append(Score);
     	sb.append(",");
        sb.append(lowestScoreDealer);
     	sb.append(",");
     	sb.append(highestScoreDealer);
     	pw.write(sb.toString());
     	pw.close();
     
    
     
     
     	List<DataSample> testingData = null;
		try 
		{
			testingData = readData(false, Type);
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     	// classify all test data
     	List<String> predictions = new ArrayList<String>();
     
     
    
     
     	// classify all test data
        for (DataSample dataSample : testingData) 
     	{
        	predictions.add(Tree.classify(dataSample).getPrintValue());

     	}
     
     
	    
     	Hit = Integer.parseInt(predictions.get(0));     
		
		
		return Hit;
	}
	
	
	
	private static List<FeatureInterface> getFeatures() 
	{
		  
		  FeatureInterface LessThan17 = Feature.newFeature("CurrentScore", Pred.lessThanD(17), "less than 17");
		  FeatureInterface GreaterThan17 = Feature.newFeature("CurrentScore", Pred.moreThanD(16), "17 or greater");
		  FeatureInterface LessThan10 = Feature.newFeature("CurrentScore", Pred.lessThanD(10), "less than 10");
		  FeatureInterface GreaterThan10 = Feature.newFeature("CurrentScore", Pred.moreThanD(9), "10 or greater");
		  FeatureInterface DealerLowScoreUnder10 = Feature.newFeature("LowestScoreDealer", Pred.lessThanD(10), "lessThan10");
		  FeatureInterface DealerLowScore10OrOver = Feature.newFeature("LowestScoreDealer", Pred.moreThanD(9), "10 or more");
		  FeatureInterface DealerHighScore17OrOver = Feature.newFeature("HighestScoreDealer", Pred.moreThanD(16), " dealer has 17 or greater");
		  FeatureInterface DealerHighScoreUnder17 = Feature.newFeature("HighestScoreDealer", Pred.lessThanD(17), " dealer has less Than 17");
	      
	      return Arrays.asList(LessThan17, GreaterThan17,LessThan10, GreaterThan10, DealerLowScoreUnder10, DealerLowScore10OrOver,DealerHighScore17OrOver,DealerHighScoreUnder17);

	}
	

	private static class ParseBooleanLabel extends ParseBool 
	{
	      
		 public Object execute(final Object value, final CsvContext context)
	     {
	         Boolean parsed = (Boolean)super.execute(value, context);
	         return parsed ? BooleanLabel.TRUE_LABEL : BooleanLabel.FALSE_LABEL;
	     }
	      
	}
	  
	  
	  
	  
	private static CellProcessor[] getProcessors(boolean training) 
	{
		     
	      if (training) 
	      {
	    	  final CellProcessor[] processors = new CellProcessor[] { 
	                  new Optional(new ParseBooleanLabel()),
	                  new Optional(new ParseInt()),
	                  new Optional(new ParseInt()),
	                  new Optional(new ParseInt())
	          };
	          return processors;
	      } else {
	          final CellProcessor[] processors = new CellProcessor[] { 
	                  new Optional(new ParseInt()),
	                  new Optional(new ParseInt()),
	                  new Optional(new ParseInt())
	          };
	          return processors;
	      }
	  }
	  
	  
	private static List<DataSample> readData(boolean training, int type) throws IOException 
	{
		  String filename = null;
		  
	      List<DataSample> data = new ArrayList<DataSample>();
	      
	      if(type == 0)
	      {
	    	  filename = training ? "/Users/assas/Desktop/train.csv" : "/Users/assas/Desktop/test.csv";
	      }
	      else if(type == 1)
	      {
	    	  filename = training ? "/Users/assas/Desktop/Randtrain.csv" : "/Users/assas/Desktop/test.csv";
	      }
	      else
	      {
	    	  filename = training ? "/Users/assas/Desktop/RefinedTestData1.csv" : "/Users/assas/Desktop/test.csv";
	      }
	      
	      
	      InputStream inputStream = new FileInputStream(filename);
	      InputStreamReader stream = new InputStreamReader(inputStream);
	      
	      try (ICsvListReader listReader = new CsvListReader(stream, CsvPreference.STANDARD_PREFERENCE);) 
	      {
	          
	          // the header elements are used to map the values to the bean (names must match)
	          final String[] header = listReader.getHeader(true);
	          
	          List<Object> values;
	          while ((values = listReader.read(getProcessors(training))) != null) 
	          {
	              data.add(Data.newData("Hit", header, values.toArray()));
	          }
	     }
	         
	     return data;  
	 }
	  
	  
	  
	  
	  
	  
	
}
