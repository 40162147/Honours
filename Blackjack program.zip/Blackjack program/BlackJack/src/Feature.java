import java.util.Optional;
import java.util.function.Predicate;

public class Feature<T> implements FeatureInterface
{
	private String data;
	
	private Predicate<T> predicate;
	
	private String label;
	
	
	private Feature(String data, Predicate<T> predicate, String label)
	{
		super();
		this.data = data;
		this.predicate = predicate;
		this.label = label;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean belongsTo(DataSample dataSample)
	{
		
		Optional<Object> optionalValue = dataSample.getValue(data);
		
		
		return optionalValue.isPresent() ? predicate.test((T)optionalValue.get()) : false;
		
	}
	
	public String toString()
	{
		return label;
	}
	
	
	
	
	public static <T> FeatureInterface newFeature(String data, T featureValue) 
   {
		return new Feature<T>(data, Pred.isEqual(featureValue), String.format("%s = %s", data, featureValue));
   }


	public static <T> FeatureInterface newFeature(String data, Predicate<T> predicate, String predicateString) 
	{
		return new Feature<T>(data, predicate, String.format("%s %s", data, predicateString));
    }



	public boolean equals(Object obj) 
	{
		if (this == obj)
		{
			return true;
		}
	            
	    if (obj == null)
	    {
	    	return false;
	    }
	            
	    if (getClass() != obj.getClass())
	    {
	    	return false;
	    }
	            
	    
	    
	    @SuppressWarnings("rawtypes")
		Feature other = (Feature) obj;
	    
	    if (data == null) 
	    {
	    	if (other.data != null)
	    	{
	    		 return false;
	    	}
	    }
	    else if (!data.equals(other.data))
	    {
	    	return false;
	    }
	            
	    if (label == null) 
	    {
	    	if (other.label != null)
	        {
	    		return false;
	        }
	    }            
	    else if (!label.equals(other.label))
	    {
	    	return false;
	    }
	            
	    if (predicate == null) 
	    {
	    	if (other.predicate != null)
	    	{
	    		return false;
	    	}
	                
	    } 
	    else if (!predicate.equals(other.predicate))
	    {
	    	 return false;
	    }
	           
	    return true;
	 }

	
}
