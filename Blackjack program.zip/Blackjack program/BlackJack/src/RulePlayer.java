
public class RulePlayer extends Player 
{
	
	int Play(int Points, int DealerLow, int DealerHigh)
	{
		Score = Points;
		
		if(Score > 16)
		{
			Hit = 0;
		}
		else
		{
			Hit = 1;
		}
	
		return Hit;
	}
}
