import java.util.List;

public interface Randomness 
{
	
	
	/**
     * Calculates impurity value. High impurity implies low information gain and more random labels of data which in
     * turn means that split is not very good.
     * 
     * @param splitData
     *            Data subset on which impurity is calculated.
     * 
     * @return Impurity.
     */
    double calculateImpurity(List<DataSample> splitData);

    
    /**
     * Calculate and return empirical probability of positive class. p+ = n+ / (n+ + n-).
     * 
     * @param splitData Data on which positive label probability is calculated.
     * @return Empirical probability.
     */
    default double getEmpiricalProbability(List<DataSample> splitData, Label positive, Label negative) 
    {
      
        return (double)splitData.parallelStream().filter(d -> d.getLabel().equals(positive)).count() / splitData.size();
    }

}
