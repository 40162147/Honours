import java.util.List;
import java.util.stream.Collectors;



public class Entropy implements Randomness
{
	 @Override
	 public double calculateImpurity(List<DataSample> splitData) 
	 {
		 List<Label> labels = splitData.parallelStream().map(data -> data.getLabel()).distinct().collect(Collectors.toList());
	     if (labels.size() > 1) 
	     {
	    	 double p = getEmpiricalProbability(splitData, labels.get(0), labels.get(1)); // TODO fix to multiple labels
	         return  -p * (Math.log(p)/Math.log(2)) - ((1.0 - p) * (Math.log(1.0 - p)/Math.log(2)));
	     } 
	     else if (labels.size() == 1) 
	     {
	    	 return 0.0; // if only one label data is pure
	     } 
	     else 
	     {
	    	 throw new IllegalStateException("This should never happen. Probably a bug.");
	     }
	 }
}
