import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseBool;
import org.supercsv.cellprocessor.ParseDouble;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvListReader;
import org.supercsv.io.ICsvListReader;
import org.supercsv.prefs.CsvPreference;
import org.supercsv.util.CsvContext;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.CardAdapter;
import ch.aplu.jcardgame.CardGame;
import ch.aplu.jcardgame.Deck;
import ch.aplu.jcardgame.Hand;
import ch.aplu.jcardgame.RowLayout;
import ch.aplu.jcardgame.StackLayout;
import ch.aplu.jcardgame.TargetArea;
import ch.aplu.jgamegrid.Actor;
import ch.aplu.jgamegrid.GGButton;
import ch.aplu.jgamegrid.GGButtonListener;
import ch.aplu.jgamegrid.Location;
import ch.aplu.util.Monitor;

import org.neuroph.core.*;



public class BlackJack1 extends CardGame 
{ 
	public enum Suit 
	{     
		SPADES, HEARTS, DIAMONDS, CLUBS   
	} 
	public enum Rank 
	{    
		ACE, KING, QUEEN, JACK, TEN, NINE, EIGHT, SEVEN, SIX, FIVE, FOUR, THREE, TWO
	}


  private Location upperLocation  = new Location (600, 600); 
  private Location bottomLocation  = new Location ( 600, 600);
  private Location middleLocation  = new Location ( 600, 600);
  private Location hideLocation  = new Location ( - 500 ,  - 500 ); 
  private Location gameOverLocation  = new Location ( 300, 300); 
  
 
  
  List<Player> Players = new ArrayList<>();
  List<Player> Dealers = new ArrayList<>();
  
  RandomPlayer rand = new RandomPlayer();
  RulePlayer rule = new RulePlayer();
  NeuralNetPlayer Nrand = new NeuralNetPlayer();
  NeuralNetPlayer Nrule = new NeuralNetPlayer();
  NeuralNetPlayer Nrefined = new NeuralNetPlayer();
  DecisionTreePlayer Drand = new DecisionTreePlayer();
  DecisionTreePlayer Drule = new DecisionTreePlayer();
  DecisionTreePlayer Drefined = new DecisionTreePlayer();
  

  
  String player1name;
  String dealername;
  int currentPlayer = 0;
  int currentDealer = 0;
  int players;
  int dealers;
  int played = 0;
  int win = 0;
  int draw = 0;
  int lose = 0;
  int bust = 0;
  int currentscorePlayer;
  int lowestScoreDealer;
  int highestScoreDealer;
  int lowestScorePlayer;
  int highestScorePlayer;
 

  
  private Deck deck  = new Deck ( Suit.values(), Rank.values(),  "cover" ) ;
  private Hand dealer  = new Hand ( deck);
  private Hand player = new Hand ( deck);
  private Actor gameOverActor  = new Actor ( "sprites/gameover.gif" ) ;
  private GGButton standButton  = new GGButton ( "sprites/standBtn.gif" ) ; 
  public GGButton restartButton  = new GGButton ( "sprites/restartBtn.gif" ) ; 
  private Hand talon; 
  
  public BlackJack1() throws IOException
  { 
	  super ( 1200, 900, 30);
	  setTitle( "BlackJack - Extended Version" );
	  setStatusText ( "Dealing out. Please wait ..." );
	  initButtons();
	 
	  rand.create("RandPlayer");
	  rule.create("RulePlayer");
	  Nrand.create("NeuralRandPlayer", "/Users/assas/Desktop/2HiddenRandom.nnet");
	  Nrule.create("NeuralRulePlayer", "/Users/assas/Desktop/2HiddenRule.nnet");
	  Nrefined.create("NeuralRefinedPlayer", "/Users/assas/Desktop/2HiddenRefined.nnet");
	  Drand.create("DecisionRandPlayer", 1);
	  Drule.create("DecisionRulePlayer", 0);
	  Drefined.create("DecisionRefinedPlayer", 2);
	  
	 

	  Players.add(Drand);
	  Players.add(Drule);
	  Players.add(Drefined);
	  Players.add(rand);
	  Players.add(rule);
	  Players.add(Nrand);
	  Players.add(Nrule);
	  Players.add(Nrefined);

	  
	  players = Players.size();
	  
	  Dealers.add(Drand);
	  Dealers.add(Drule);
	  Dealers.add(Drefined);
	  Dealers.add(rand);
	  Dealers.add(rule);
	  Dealers.add(Nrand);
	  Dealers.add(Nrule);
	  Dealers.add(Nrefined);

	  
	  dealers = Dealers.size();
	  
	  while ( true )     
	  {       
		  
		  init();
		  //Monitor.putSleep();
	  } 
  } 

  private void showHands()   
{ 
	RowLayout rowLayout  = new RowLayout ( bottomLocation, 350);
	player.setView ( this ,  rowLayout);
	player.draw ();
	RowLayout rowLayout1  = new RowLayout ( upperLocation, 350);
	dealer.setView ( this ,  rowLayout1);
	dealer.draw ();
	talon.setVerso ( true );
	talon.setView ( this ,  new StackLayout ( middleLocation)); 
	talon.draw (); 
} 

  private void init () throws IOException
{   
	
	
	talon  = deck.dealingOut (0, 0, true)[0];
	showHands();
	Card card  = talon.getLast ();
	talon.transfer (card, player,  true ) ;
	lowestScorePlayer = getHandValue(player) + 1;
	highestScorePlayer = getHandValue(player) + 11;
	card.setVerso ( false ) ;
	card  = talon.getLast ();
	card.setVerso ( false ) ;
	talon.transfer (card, dealer,  true ) ;
	lowestScoreDealer = getHandValue(dealer) + 1;
	highestScoreDealer = getHandValue(dealer) + 11;
	card  =  talon.getLast (); 
    talon.transfer (card, player,  true ) ; 
    card.setVerso ( false ) ; 
    card  =  talon.getLast (); 
    talon.transfer (card, dealer,  true ) ; 
    card.setVerso ( false );
    

	
	
	player1Turn();
	
    evaluateRound ();
 
	
} 



  public void initButtons () 
{ 
	
	
    restartButton.addButtonListener (new GGButtonListener()
    { 
    	public void buttonClicked ( GGButton button)       
    	{        

    		 restartButton.setLocation (hideLocation);
     		 cleanUp();
     		 Monitor.wakeUp();
    	} 
    	

    	public void buttonReleased ( GGButton button){ };      
    	public void buttonPressed ( GGButton button) { };
    });
    
    addActor (restartButton, hideLocation);
    restartButton.setRefreshEnabled ( false );
    
    standButton.addButtonListener ( new GGButtonListener()
    { 
    	public void buttonClicked ( GGButton button)       
    	{         
    		standButton.setLocation (hideLocation);
    		
    		PrintWriter pw = null;
  		  	try 
  		  	{
  		  		pw = new PrintWriter(new FileOutputStream(new File("Training.csv"), true));
  		  	} 
  		  	catch (FileNotFoundException e) 
  		  	{
  		  		// TODO Auto-generated catch block
  		  		e.printStackTrace();
  		  	}
  		  	StringBuilder sb = new StringBuilder();
  		  
  	      
  		  	sb.append(0);
  		  	sb.append(',');
  		  	sb.append(getHandValue(player));
  		  	sb.append(',');
  		  	sb.append(lowestScoreDealer);
  		  	sb.append(',');
  		  	sb.append(highestScoreDealer);
  		  	sb.append('\n');
  	      
  		  	pw.write(sb.toString());
  		  	pw.close();
    		
    		//dealersTurn ();         
    		evaluateRound ();
    		
    	}

    	public void buttonReleased ( GGButton button){ };      
    	public void buttonPressed ( GGButton button) { };
    });
    
    addActor (standButton, hideLocation);   
    standButton.setRefreshEnabled ( false ) ; 
    
    
  } 

  private void cleanUp ()  
  {     
	  gameOverActor.removeSelf();
	  talon.removeAll ( false ) ;
	  player.removeAll ( false ) ;
	  dealer.removeAll ( false ) ;
  } 
  
  private void evaluateRound ()   
  { 
	  
	  int dealerValue  = getHandValue (dealer);
	  int playerValue  = getHandValue (player);
	  String score  = playerValue  + "(you) versus " + dealerValue  + " (dealer)--- Please click to restart." ;
	  if (dealerValue  > 21)
	  {
		  
		  win = win + 1;
		  gameOver ( "Dealer bust! " + score);
		    
	  }	
	  
	  else if (playerValue < 22 && playerValue > dealerValue )
	  {
		  
		  win = win + 1;
		  gameOver ("Player1 Won" + score);
		    
	  }
	  
	  else if(playerValue > 21)
	  {
		  
		  bust = bust + 1;
		  gameOver ("Player1 bust " + score);
		   
	  }
	  
	  else if(playerValue == dealerValue)
	  {
		  
		  draw = draw + 1;
		  gameOver ("Dealer tied" + score);
		    
	  }
	  else
	  {  
		  lose = lose + 1;
		  gameOver ("Dealer Won" + score);
		  
	  }
	  

  
  }   
  
  private void gameOver ( String reason)  
  {     
	  dealer.setVerso ( false ) ;
	  player.setVerso( false );
	  setStatusText (reason);
	  talon.setTouchEnabled ( false ) ;
	  addActor (gameOverActor, gameOverLocation);
	  standButton.setLocation (hideLocation);
	 // restartButton.setLocation (buttonLocation);
	  if (played < 99)
	  {
		  played++;
		  cleanUp();
		  
	  }
	  else
	  {
		  
		  PrintWriter pw = null;
		try {
			pw = new PrintWriter(new FileOutputStream(new File("Output.csv"),true));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  StringBuilder sb = new StringBuilder();
		  
		  
		  sb.append(Players.get(currentPlayer).Name + " VS " + Dealers.get(currentDealer).Name);
	      sb.append('\n');
		  
		  sb.append("Win");
	      sb.append(',');
	      sb.append("Lose");
	      sb.append(',');
	      sb.append("Bust");
	      sb.append(',');
	      sb.append("Draw");
	      sb.append('\n');
	      
	      sb.append(win);
	      sb.append(',');
	      sb.append(lose);
	      sb.append(',');
	      sb.append(bust);
	      sb.append(',');
	      sb.append(draw);
	      sb.append('\n');
	      
		  pw.write(sb.toString());
	      pw.close();
	      
	      played = 0;
	      win = 0;
	      lose = 0;
	      draw = 0;
	      bust = 0;
	      
	      
	      
		  if(currentDealer >= dealers - 1)
		  {
			  if(currentPlayer >= players - 1)
			  {
				  System.exit(0);
			  }
			  else
			  {
				  currentPlayer++;
				  currentDealer = 0;
			  }
		  }
		  else
		  {
			  currentDealer++;
		  }
		  
		  cleanUp();
	  }

  } 
  
  private void dealersTurn () throws IOException   
  {     
	  talon.setTargetArea ( new TargetArea ( dealer.getHandLocation ()));  
     
	  while  (Dealers.get(currentDealer).Play(getHandValue(dealer), lowestScorePlayer, highestScorePlayer) != 0 && getHandValue(dealer) <22) 
	  { 
		  Card  newCard  =  talon.getLast (); 
		  newCard.transfer (dealer,  true ) ; 
		  newCard.setVerso ( false ) ; 
	  } 
	  
	  
  } 
  

  
  private void player1Turn () throws  FileNotFoundException, IOException
  {
	  talon.setTargetArea ( new TargetArea ( player.getHandLocation ()));   
	  
	  while  (Players.get(currentPlayer).Play(getHandValue(player), lowestScoreDealer, highestScoreDealer) != 0 && getHandValue(player) <22) 
	  { 
		  Card  newCard  =  talon.getLast (); 
		  newCard.transfer (player,  true ) ; 
		  newCard.setVerso ( false ) ; 
	  } 
	  
	  if(getHandValue(player) < 22)
	  {
		  dealersTurn();
	  }
	  
	  

      
  }

  private int getHandValue ( Hand handle)   
  { 
	  int value  = 0; 
	  for (Card card: handle.getCardList ())
	  { 
		  switch (( Rank ) card.getRank ())       
	  
		  { 
	  		case  TWO:  
	  			value  +=  2; 
	  			break ; 
	  		case  THREE:
	  			value  +=  3; 
	  			break ; 
	  		case  FOUR:
	  			value  +=  4; 
	  			break ; 
	  		case  FIVE:
	  			value  +=  5; 
	  			break ; 
	  		case  SIX:
	  			value  +=  6; 
	  			break ; 
	  		case  SEVEN:
	  			value  +=  7; 
	  			break ; 
	  		case  EIGHT:
	  			value  +=  8;
	  			break ; 
	  		case  NINE:
	  			value  +=  9; 
	  			break ; 
	  		case  TEN:
	  			value  +=  10; 
	  			break ; 
	  		case  JACK:
	  			value  +=  10; 
	  			break ; 
	  		case  QUEEN:
	  			value  +=  10; 
	  			break ; 
	  		case  KING:
	  			value  +=  10; 
	  			break ; 
	  		case  ACE: 
	  			if  (value  +  11  >  21) 
	  				value +=  1; 
	  			else 
	  				value  +=  11; 
	  			break ; 
		  } 
	  } 
	return value; 
  	} 
  
  
  

  
  public static void main (String [] args) throws IOException 
  { 

	  
	  new BlackJack1 ();   
  } 
  
  
  

  
  
}  

 
         