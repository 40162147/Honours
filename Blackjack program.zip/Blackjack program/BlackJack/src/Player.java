
public class Player 
{
	
	String Name;
	int Win;
	int Lose;
	int Draw;
	int Score;
	int lowestScoreDealer;
	int highestScoreDealer;
	int Hit;
	
	public void create(String id)
	{
		Name = id;
	}
	
	
	int Play(int Points, int DealerLow, int DealerHigh)
	{
		
		
		return 0;
	}
	
	
}
