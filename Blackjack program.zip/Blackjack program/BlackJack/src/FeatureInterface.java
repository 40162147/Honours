import static java.util.stream.Collectors.partitioningBy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public interface FeatureInterface 
{
	
	
    boolean belongsTo(DataSample dataSample);

    default List<List<DataSample>> split(List<DataSample> data) 
    {
        
    	List<List<DataSample>> result = new ArrayList<List<DataSample>>();

        Map<Boolean, List<DataSample>> split = data.parallelStream().collect(partitioningBy(dataSample -> belongsTo(dataSample)));
        
        if (split.get(true).size() > 0) 
        {
            result.add(split.get(true));
        } 
        else 
        {
        	result.add(new ArrayList<DataSample>());
        }
        
        if (split.get(false).size() > 0) 
        {
            result.add(split.get(false));
        } 
        else 
        {
            result.add(new ArrayList<DataSample>());
        }
        return result;
    }

}
