import java.util.HashMap;
import java.util.Map;
import java.util.Optional;





public class Data implements DataSample
{
	
	
	private Map<String, Object> values = new HashMap<String, Object>();
    
    /** Column name which contains data labels. */
    private String labelColumn;
    
    private Data(String labelColumn, String[] header, Object... dataValues) 
    {
        super();
        this.labelColumn = labelColumn;
        for (int i = 0; i < header.length; i++) 
        {
            this.values.put(header[i], dataValues[i]);
        }
    }

    @Override
    public Optional<Object> getValue(String column) 
    {
        return Optional.ofNullable(values.get(column));
    }
    
    @Override
    public Label getLabel() 
    {
    	
        return (Label)values.get(labelColumn);
    }

    /**
     * Create data sample without labels which is used on trained tree.
     */
    public static Data newClassificationData(String[] header, Object... values) 
    {
        return new Data(null, header, values);
    }

    /**
     * @param labelColumn
     * @param header
     * @param values
     * @return
     */
    public static Data newData(String labelColumn, String[] header, Object... values) 
    {  
        return new Data(labelColumn, header, values);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        return "SimpleDataSample [values=" + values + "]";
    }
}
